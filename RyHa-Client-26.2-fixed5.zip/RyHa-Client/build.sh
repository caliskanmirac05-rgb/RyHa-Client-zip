#!/usr/bin/env bash
# RyHa Client — one-command build script
set -e

echo "╔══════════════════════════════════╗"
echo "║      RyHa Client Builder         ║"
echo "╚══════════════════════════════════╝"
echo ""

# Check Java version
JAVA_VER=$(java -version 2>&1 | awk -F '"' '/version/ {print $2}' | cut -d'.' -f1)
if [ "$JAVA_VER" -lt 21 ] 2>/dev/null; then
    echo "ERROR: Java 21+ required (found Java $JAVA_VER)"
    exit 1
fi

echo "→ Java $JAVA_VER detected"
echo "→ Running Gradle build..."
echo ""

./gradlew build --info 2>&1 | grep -E "(BUILD|FAILED|error:|warning:|Task |ryha)"

JAR=$(ls build/libs/ryha-client-*.jar 2>/dev/null | grep -v sources | head -1)

if [ -n "$JAR" ]; then
    echo ""
    echo "✓ Build successful!"
    echo "  Output: $JAR"
    echo ""
    echo "Install: copy $JAR to .minecraft/mods/"
else
    echo "✗ Build failed — check output above"
    exit 1
fi
